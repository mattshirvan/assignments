from django.apps import AppConfig


class BjjAppConfig(AppConfig):
    name = 'bjj_app'
